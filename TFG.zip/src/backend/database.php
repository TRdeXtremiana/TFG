<?php

// Configuración de la base de datos
define('DB_HOST', 'localhost');
define('DB_NAME', 'gestorgastos');
define('DB_USER', 'root');
define('DB_PASS', '');  // Cambia esta contraseña si es necesario

/**
 * Función para conectar a la base de datos usando PDO
 * Muestra mensajes de éxito o error en la consola.
 */
function connect_db()
{
	// Usar variable estática para mantener una conexión persistente
	static $pdo = null;

	if ($pdo === null) {
		try {
			// Crear la conexión usando PDO
			$pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
			$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  // Manejo de errores
			$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);  // Fetch como array asociativo
			$pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);  // Deshabilitar emulación de preparaciones

			// Mostrar mensaje de éxito en la consola
			echo "Conexión exitosa a la base de datos.\n";
		} catch (PDOException $e) {
			// Mostrar mensaje de error en la consola
			echo "Error de conexión: " . $e->getMessage() . "\n";
		}
	}

	return $pdo;
}

connect_db();