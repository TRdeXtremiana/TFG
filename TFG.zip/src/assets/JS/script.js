async function postData(url, data) {
    return await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
    });
}

function showExpenseMessage(message, isSuccess) {
    const messageSpan = document.getElementById('expense-message');
    messageSpan.textContent = message;
    messageSpan.className = isSuccess ? 'success' : 'error';
    messageSpan.classList.remove('hidden');
    setTimeout(() => {
        messageSpan.classList.add('hidden');
        messageSpan.textContent = '';
    }, 5000);
}

async function addExpense(expenseData) {
    const button = document.getElementById('submit-button');
    const spinner = document.getElementById('spinner');
    button.disabled = true;
    spinner.classList.remove('hidden');

    try {
        const response = await postData("../backend/controllers/expensesController.php", expenseData);
        if (response.ok) {
            const data = await response.json();
            showExpenseMessage(data.message || 'Gasto añadido con éxito', true);
            // Actualiza gráficos
            updateCharts(data.updatedCategories, data.updatedAmounts);
        } else {
            const error = await response.json();
            showExpenseMessage(error.error || 'Error al añadir el gasto', false);
        }
    } catch (error) {
        showExpenseMessage('Error al conectar con el servidor', false);
    } finally {
        button.disabled = false;
        spinner.classList.add('hidden');
    }
}


function handleExpenseFormSubmit(event) {
    event.preventDefault();
    const amount = document.getElementById("amount").value;
    const category = document.getElementById("category").value;
    const description = document.getElementById("description").value || null;
    const date = document.getElementById("date").value;

    if (!amount || amount <= 0) {
        showExpenseMessage('La cantidad debe ser mayor que 0', false);
        return;
    }

    addExpense({ amount, category, description, date });
}

function createChartConfig(type, labels, data) {
    return {
        type,
        data: {
            labels,
            datasets: [{
                label: 'Gastos por Categoría',
                data,
                backgroundColor: ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99'],
                borderColor: '#fff',
                borderWidth: 1,
            }],
        },
        options: { scales: { y: { beginAtZero: true } } },
    };
}

function toggleCharts() {
    const pieChart = document.getElementById('pie-chart');
    const barChart = document.getElementById('bar-chart');
    const isPieVisible = pieChart.style.display !== 'none';
    pieChart.style.display = isPieVisible ? 'none' : 'block';
    barChart.style.display = isPieVisible ? 'block' : 'none';
}

function init() {
    document.getElementById("expense-form").addEventListener("submit", handleExpenseFormSubmit);
    const pieData = { labels: ['Ocio', 'Transporte'], datasets: [{ data: [120, 80] }] };
    const barData = { labels: ['Ocio', 'Transporte'], datasets: [{ data: [120, 80] }] };

    new Chart(document.getElementById('pie-chart'), createChartConfig('pie', pieData.labels, pieData.datasets[0].data));
    new Chart(document.getElementById('bar-chart'), createChartConfig('bar', barData.labels, barData.datasets[0].data));
    document.getElementById('bar-chart').style.display = 'none';
}

document.addEventListener("DOMContentLoaded", init);
