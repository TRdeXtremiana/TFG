-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-12-2024 a las 11:41:56
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `gestorgastos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `expenses`
--

CREATE TABLE `expenses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` text DEFAULT NULL,
  `date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `expenses`
--

INSERT INTO `expenses` (`id`, `user_id`, `tag_id`, `amount`, `description`, `date`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 120.50, 'Compra en el supermercado', '2024-12-01', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(2, 2, 2, 60.00, 'Cena en restaurante', '2024-12-02', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(3, 3, 3, 200.00, 'Concierto de música', '2024-12-03', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(4, 4, 4, 500.00, 'Ahorro mensual', '2024-12-04', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(5, 5, 5, 80.00, 'Compra de ropa', '2024-12-05', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(6, 6, 6, 40.00, 'Medicinas', '2024-12-06', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(7, 7, 7, 150.00, 'Curso online', '2024-12-07', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(8, 8, 8, 300.00, 'Viaje de fin de semana', '2024-12-08', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(9, 9, 9, 25.00, 'Comida para perro', '2024-12-09', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(10, 10, 10, 100.00, 'Donación a ONG', '2024-12-10', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(11, 11, 11, 70.00, 'Gimnasio mensual', '2024-12-11', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(12, 12, 12, 350.00, 'Compra de un nuevo móvil', '2024-12-12', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(13, 13, 13, 500.00, 'Compra de refrigerador', '2024-12-13', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(14, 14, 14, 200.00, 'Auriculares inalámbricos', '2024-12-14', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(15, 15, 15, 120.00, 'Entrada al parque de diversiones', '2024-12-15', '2024-12-24 10:41:02', '2024-12-24 10:41:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `color` varchar(7) DEFAULT '#000000',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tags`
--

INSERT INTO `tags` (`id`, `user_id`, `name`, `color`, `created_at`) VALUES
(1, 1, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(2, 1, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(3, 1, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(4, 2, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(5, 2, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(6, 2, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(7, 3, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(8, 3, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(9, 3, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(10, 4, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(11, 4, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(12, 4, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(13, 5, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(14, 5, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(15, 5, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(16, 6, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(17, 6, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(18, 6, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(19, 7, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(20, 7, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(21, 7, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(22, 8, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(23, 8, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(24, 8, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(25, 9, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(26, 9, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(27, 9, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(28, 10, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(29, 10, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(30, 10, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(31, 11, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(32, 11, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(33, 11, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(34, 12, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(35, 12, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(36, 12, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(37, 13, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(38, 13, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(39, 13, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(40, 14, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(41, 14, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(42, 14, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(43, 15, 'Necesarios', '#FF0000', '2024-12-24 10:41:02'),
(44, 15, 'Ocio', '#00FF00', '2024-12-24 10:41:02'),
(45, 15, 'Transporte', '#0000FF', '2024-12-24 10:41:02'),
(46, 1, 'Hogar', '#123456', '2024-12-24 10:41:02'),
(47, 2, 'Comida', '#654321', '2024-12-24 10:41:02'),
(48, 3, 'Entretenimiento', '#abcdef', '2024-12-24 10:41:02'),
(49, 4, 'Ahorros', '#ff9900', '2024-12-24 10:41:02'),
(50, 5, 'Ropa', '#336699', '2024-12-24 10:41:02'),
(51, 6, 'Salud', '#ff6600', '2024-12-24 10:41:02'),
(52, 7, 'Educación', '#9900cc', '2024-12-24 10:41:02'),
(53, 8, 'Viajes', '#33cc33', '2024-12-24 10:41:02'),
(54, 9, 'Mascotas', '#cc0000', '2024-12-24 10:41:02'),
(55, 10, 'Donaciones', '#ff0033', '2024-12-24 10:41:02'),
(56, 11, 'Deportes', '#0033cc', '2024-12-24 10:41:02'),
(57, 12, 'Tecnología', '#999999', '2024-12-24 10:41:02'),
(58, 13, 'Electrodomésticos', '#6666ff', '2024-12-24 10:41:02'),
(59, 14, 'Gadgets', '#00ccff', '2024-12-24 10:41:02'),
(60, 15, 'Diversión', '#33ffcc', '2024-12-24 10:41:02');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'user1', 'user1@example.com', 'password1', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(2, 'user2', 'user2@example.com', 'password2', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(3, 'user3', 'user3@example.com', 'password3', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(4, 'user4', 'user4@example.com', 'password4', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(5, 'user5', 'user5@example.com', 'password5', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(6, 'user6', 'user6@example.com', 'password6', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(7, 'user7', 'user7@example.com', 'password7', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(8, 'user8', 'user8@example.com', 'password8', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(9, 'user9', 'user9@example.com', 'password9', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(10, 'user10', 'user10@example.com', 'password10', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(11, 'user11', 'user11@example.com', 'password11', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(12, 'user12', 'user12@example.com', 'password12', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(13, 'user13', 'user13@example.com', 'password13', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(14, 'user14', 'user14@example.com', 'password14', '2024-12-24 10:41:02', '2024-12-24 10:41:02'),
(15, 'user15', 'user15@example.com', 'password15', '2024-12-24 10:41:02', '2024-12-24 10:41:02');

--
-- Disparadores `users`
--
DELIMITER $$
CREATE TRIGGER `after_user_insert` AFTER INSERT ON `users` FOR EACH ROW BEGIN
    INSERT INTO tags (user_id, name, color) VALUES
    (NEW.id, 'Necesarios', '#FF0000'),
    (NEW.id, 'Ocio', '#00FF00'),
    (NEW.id, 'Transporte', '#0000FF');
END
$$
DELIMITER ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Indices de la tabla `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_tag_per_user` (`user_id`,`name`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `expenses`
--
ALTER TABLE `expenses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `expenses_ibfk_2` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`);

--
-- Filtros para la tabla `tags`
--
ALTER TABLE `tags`
  ADD CONSTRAINT `tags_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
